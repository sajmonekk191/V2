﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoidSharp.Other
{
    internal class Champions
    {
        public static string aphelios = "https://1.bp.blogspot.com/-R5ozICNl7AY/Xd2iaJ1x8wI/AAAAAAABb1c/Lkeeq4TPd7c7Hn2ThLeJe1fDE8dq5p2LgCLcBGAsYHQ/s1600/523.png";
        public static string ashe = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/4/4a/AsheSquare.png/revision/latest/scale-to-width-down/120?cb=20170728180206";
        public static string caitlyn = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/e/e6/CaitlynSquare.png/revision/latest/scale-to-width-down/120?cb=20170801175326";
        public static string corki = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/3/3d/CorkiSquare.png/revision/latest/scale-to-width-down/120?cb=20170801184703";
        public static string draven = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/d/d7/DravenSquare.png/revision/latest/scale-to-width-down/120?cb=20170801201235";
        public static string ezreal = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/c/c3/EzrealSquare.png/revision/latest/scale-to-width-down/120?cb=20170801212628";
        public static string jinx = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/e/e2/JinxSquare.png/revision/latest/scale-to-width-down/120?cb=20170802020615";
        public static string kaisa = "https://2.bp.blogspot.com/-D9B7VI6NQ80/Wo3UldSXIsI/AAAAAAAA5e4/a0M9fo4_vcUmsdWvfgalyJOR9Vs6vW1EQCEwYBhgL/s1600/145.png";
        public static string kalista = "https://static.wikia.nocookie.net/leagueoflegends/images/4/4d/Kalista_OriginalSquare.png/revision/latest?cb=20170401005336";
        public static string kayle = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/b/bd/KayleSquare.png/revision/latest/scale-to-width-down/120?cb=20190918193910";
        public static string kindred = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/6/6e/KindredSquare.png/revision/latest/scale-to-width-down/120?cb=20170802031055";
        public static string kogmaw = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/4/45/Kog%27MawSquare.png/revision/latest/scale-to-width-down/120?cb=20170802031916";
        public static string lucian = "https://img.rankedboost.com/wp-content/plugins/league/assets/champion-icons/Lucian-Icon.png";
        public static string missfortune = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/9/9d/MissFortuneSquare.png/revision/latest/scale-to-width-down/120?cb=20170802061243";
        public static string quinn = "https://img.rankedboost.com/wp-content/plugins/league-of-legends-wild-rift/assets/champion-icons/Quinn-Icon.png";
        public static string samira = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/b/b3/SamiraSquare.png/revision/latest/scale-to-width-down/120?cb=20200830082811";
        public static string sivir = "https://img.rankedboost.com/wp-content/plugins/league/assets/champion-icons/Sivir-Icon.png";
        public static string teemo = "https://static.wikia.nocookie.net/leagueoflegends/images/9/9c/Teemo_OriginalSquare.png/revision/latest?cb=20150402221254";
        public static string tristana = "https://acqwmovtio.cloudimg.io/v7/https://ddragon.leagueoflegends.com/cdn/10.25.1/img/champion/Tristana.png?h=120";
        public static string twitch = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/7/79/TwitchSquare.png/revision/latest/scale-to-width-down/120?cb=20170802161732";
        public static string twistedfate = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/f/fb/Twisted_FateSquare.png/revision/latest/scale-to-width-down/120?cb=20170802161630";
        public static string varus = "https://acqwmovtio.cloudimg.io/v7/https://ddragon.leagueoflegends.com/cdn/10.25.1/img/champion/Varus.png?h=120";
        public static string vayne = "https://static.wikia.nocookie.net/lolesports_gamepedia_en/images/9/95/VayneSquare.png/revision/latest/scale-to-width-down/120?cb=20170802170334";
        public static string xayah = "https://img.rankedboost.com/wp-content/plugins/league/assets/champion-icons/Xayah-Icon.png";
    }
}
