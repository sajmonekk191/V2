﻿using System.Drawing;
using System.Windows.Forms;

namespace VoidSharp.Cheat
{
    internal class calls
    {
        public static void DoThing(string call)
        {
            switch (call)
            {
                case "AttackEnemy":
                    Rectangle rect = ScreenCap.GetRangeValue(Other.hodnoty.rangevalue);
                    Point enemypos = ScreenCap.PixelSearch(rect, Other.hodnoty.EnemyPix);
                    if (enemypos != null)
                    {
                        Point lastcursorpos = new Point(Cursor.Position.X, Cursor.Position.Y);
                        Cursor.Position = enemypos;
                        

                    }
                    break;
                case "FixCursor":
                    break;
            }
        }
    }
}
