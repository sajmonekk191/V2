﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;

namespace VoidSharp.Other
{
    internal class Orbwalker
    {
    }
}
