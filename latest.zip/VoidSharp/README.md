# VoidSharp
  League of Legends External Scripting Platform
  - Orbwalker (Champion Detection, Attack Everything)
  - AutoAim (Aim to Champion and use Spell)
  - AutoCleanse (Automatic Cleanse when getting stuned)
  - Little Drawings (Summoner Spells timer etc....)
  - Etcs. (Account Manager, some turbo Features)

Start project predict (16 / 03 / 2021)

Finish project predict (20 / 05 / 2022)
